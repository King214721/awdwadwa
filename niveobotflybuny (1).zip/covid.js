//modüller baş
const fs = require("fs");
const Discord = require("discord.js");
const discord = require("discord.js");
const { GatewayIntentBits } = require("discord.js");
const client = new discord.Client({ intents: [ GatewayIntentBits.FLAGS.GUILDS, GatewayIntentBits.FLAGS.GUILD_MEMBERS, GatewayIntentBits.FLAGS.GUILD_EMOJIS_AND_STICKERS, GatewayIntentBits.FLAGS.GUILD_INTEGRATIONS, GatewayIntentBits.FLAGS.GUILD_WEBHOOKS, GatewayIntentBits.FLAGS.GUILD_INVITES, GatewayIntentBits.FLAGS.GUILD_VOICE_STATES, GatewayIntentBits.FLAGS.GUILD_PRESENCES, GatewayIntentBits.FLAGS.GUILD_MESSAGES, GatewayIntentBits.FLAGS.GUILD_MESSAGE_REACTIONS, GatewayIntentBits.FLAGS.GUILD_MESSAGE_TYPING, GatewayIntentBits.FLAGS.DIRECT_MESSAGES, GatewayIntentBits.FLAGS.DIRECT_MESSAGE_REACTIONS, GatewayIntentBits.FLAGS.DIRECT_MESSAGE_TYPING,], partials: ["MESSAGE", "Channel", "REACTION"] });
const ayarlar = require("./ayarlar.json");
const db = require("inflames.db");
//modüller son
const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => res.send('Web Server Başladı.'));

app.listen(port, () =>
    console.log(`Bot bu adres üzerinde çalışıyor: http://localhost:${port}`)
);
//command handler baş
client.once("ready", () => {
  console.log(`Logged in as @${client.user.tag}!`);
});

client.slashCommands = new Discord.Collection();
client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();
fs.readdir("./handler-mainkodları/", (err, files) => {
  if (err) console.error(err); //
  console.log(`${files.length} hand yüklenecek.`);
  files.forEach((f) => {
  require(`./handler-mainkodları/${f}`)(client);
  });
});

//command handler son
//komutlar
//kurallar kodu
client.on('messageCreate', (message) => {
  if (message.content.startsWith('!yardım')) {
    const userId = message.author.id;
    const user = message.author;
  }

  if (message.content.startsWith('!kayıt')) {
    const userId = message.author.id;
    const user = message.author;

    if (db.has(`registered.${userId}`)) {
      return message.reply('**Zaten kayıtlısınız.** <:cs_reddet:1142405174548254802>');
    }

    const paraMiktarı = 100; //  para miktarı
    const dolarMiktarı = 2; //  para miktarı
    const euroMiktarı = 1; //  para miktarı
    db.set(`registered.${userId}`, true);
    db.add(`${userId}.para`, paraMiktarı);
    db.add(`${userId}.dolar`, dolarMiktarı);
    db.add(`${userId}.euro`, euroMiktarı);


    message.reply('**Kayıt işlemi başarıyla tamamlandı. Hesabınıza `100` cash ve `2` dolar eklendi. <:cs_onay:1142405258409156708>**');
  }
});
//dolar
const jsonFilePath = 'database.json';

function getRandomNumber(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function updateDolarFiyat() {
  let dolarData = {};

  try {
    const data = fs.readFileSync(jsonFilePath, 'utf-8');
    dolarData = JSON.parse(data);
  } catch (error) {
    console.error('Error reading JSON file:', error); 
  }

  const randomNum = getRandomNumber(1, 2);
  const changeAmount = Math.random() * (randomNum==2?5:0.2); // Rastgele artış veya azalış miktarı (maksimum 0.5)

  if (randomNum === 1) {
    // Dolar düşer
    dolarData.dolar -= changeAmount;
    console.log('Dolar düştü! Yeni dolar fiyatı:', dolarData.dolar);
  } else {
    // Dolar artar
    dolarData.dolar += changeAmount;
    console.log('Dolar yükseldi! Yeni dolar fiyatı:', dolarData.dolar);
  }

  try {
    dolarData.dolar = Math.floor(dolarData.dolar);
    fs.writeFileSync(jsonFilePath, JSON.stringify(dolarData, null, 2));
  } catch (error) {
    console.error('Error writing JSON file:', error);
  }
}
///dolar son
///euro
function updateEuroFiyat() {
  let euroData = {};

  try {
    const data = fs.readFileSync(jsonFilePath, 'utf-8');
    euroData = JSON.parse(data);
  } catch (error) {
    console.error('Error reading JSON file:', error); 
  }

  const randomNum = getRandomNumber(1, 2);
  const changeAmount = Math.random() * (randomNum==2?5:0.3); // Rastgele artış veya azalış miktarı (maksimum 0.5)

  if (randomNum === 1) {
    // Euro düşer
    euroData.euro -= changeAmount;
    console.log('Euro düştü! Yeni euro fiyatı:', euroData.euro);
  } else {
    // Euro artar
    euroData.euro += changeAmount;
    console.log('Euro yükseldi! Yeni euro fiyatı:', euroData.euro);
  }

  try {
    euroData.euro = Math.floor(euroData.euro);
    fs.writeFileSync(jsonFilePath, JSON.stringify(euroData, null, 2));
  } catch (error) {
    console.error('Error writing JSON file:', error);
  }
}

client.once('ready', () => {
  console.log(`Logged in as ${client.user.tag}`);

  // Belirli aralıklarla updateDolarFiyat fonksiyonunu çağırmak için zamanlayıcı
  setInterval(updateDolarFiyat, 30 * 60 * 100); // 30 dakika
  setInterval(updateEuroFiyat, 30 * 60 * 100); // 30 dakika
});


//bot oynuyor baş
client.on("ready", () => {
  client.user.setActivity(`Beni sunucuna ekleyerek hem bize destek olabilir hem sunucuna renk katabilirsin.`);
  console.log("Botun durumu ayarlandı.");
});
//bot oynuyor son
//log baş
client.once("ready", () => {
  console.log(`Başarıyla aktif oldum`);
});
//log son
//token baş
client.login(process.env.token);
//token son
//ayrıntılı hata baş
process.on("warning", (e) => console.warn(e.stack));
//ayrıntılı hata son

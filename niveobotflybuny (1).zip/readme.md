## Kurulum

Altyapıyı aldıktan sonra consola/teminale

```bash
npm i inflames.db

npm i discord.js

npm i moment

npm i fs
```

yazmanız gerekiyor hata verirse alttaki linkten ulaşabilirsiniz. (Node.js sürümünüz 16 olmalıdır, 16 değilse indirmek için:  https://nodejs.org/dist/v16.13.0/node-v16.13.0-x64.msi)
ayarlar.json adlı dosyadaki gerekli yerleri doldurun.

## Açıklama

ALtyapı lisanslıdır paylaşılması yasaktır izin isteseniz bile verilmeyecektir.
Lisans satılık değildir teklif etmeyiniz.

## Hata

Sorun olursa ya da kuramassanız discord adresimiz: https://discord.gg/HFhyNaKUB6

## https://inflames.xyz/

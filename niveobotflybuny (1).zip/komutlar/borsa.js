const Discord = require('discord.js'); //modüller
const db = require("inflames.db")

exports.run = async (client, message, args) => {
    const dolarFiyati = db.get('dolar') || 0;
    const euroFiyati = db.get('euro') || 0;
    const embed = new Discord.EmbedBuilder()
      .setColor('#030303')
      .setTitle('İşte KaraBorsa bu şekilde')
      .setDescription(`Döviz: \`\`\` Dolar ${dolarFiyati} \n Euro ${euroFiyati}\`\`\` `)
      .setTimestamp();

    message.reply({ embeds: [embed] });
}
exports.conf = {
  enabled: true, //kullanıma açık mı değil mi
  guildOnly: true, //dmde kullanıma açık mı değil mi
  aliases: ["borsa"], //kısayollar
  permLevel: 0 //perm level mainde karşıliklar yazar
};
  
exports.help = {
 name: "borsa", //komutu çalıştıracak olan kelime
 description: "",//açıklama (isteğe bağlı)
 usage: ""//kullanım (isteğe bağlı)
};
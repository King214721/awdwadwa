const { EmbedBuilder } = require('discord.js');
const db = require('inflames.db');

exports.run = async (client, message, args) => {
  const items = [
    { name: 'Dolar Basma', price: 500 },
    { name: 'Bitcoin Üretici \n!satın-al üretici-bitcoin', price: 900 }
    // Diğer eşyaları buraya ekleyin
  ];

  const embed = new EmbedBuilder()
    .setTitle('Market')
    .setDescription('**KaraBorsa Shop | Hoşgeldiniz!** \n<:icons_wumpus:1143615281709731981> Polis yakalarsa tüm 1000 cash ceza alırsın! Shop 7 cash komisyon alır!\n Miner')
    .setColor('#3498db');

  items.forEach((item) => {
    embed.addFields({ name: item.name, value: `${item.price} Cash`, inline: true });
  });

  message.reply({ embeds: [embed] });
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['market', 'items'],
  permLevel: 0,
};

exports.help = {
  name: 'market',
  description: 'Marketi görüntüler',
  usage: 'market',
};
